{-# OPTIONS_GHC -Wall #-}
{-# LANGUAGE MultiParamTypeClasses,
             TypeSynonymInstances, FlexibleInstances #-}

module GAS where

import ProblemState

import qualified Data.Map.Strict as M

{-
    Pozițiile tablei de joc, în formă (linie, coloană), unde ambele coordonate
    pot fi negative.
-}
type Position = (Int, Int)

{-
    Culorile pătratelor și cercurilor.
-}
data Color = Red | Blue | Gray
    deriving (Eq, Ord, Show)

{-
    Orientările pătratelor și săgeților.
-}
data Heading = North | South | East | West
    deriving (Eq, Ord)

instance Show Heading where
    show North = "^"
    show South = "v"
    show East  = ">"
    show West  = "<"

{-
    *** TODO ***

    Un obiect de pe tabla de joc: pătrat/ cerc/ săgeată.
-}
data Object = Square Color Heading | Circle Color | Arrow Heading
    deriving (Eq, Ord)


{-
    *** TODO ***

    Reprezetarea textuală a unui obiect.
-}
instance Show Object where
    show (Square Red heading) = "R" ++ show heading
    show (Square Blue heading) = "B" ++ show heading
    show (Square Gray heading) = "G" ++ show heading
    show (Circle Red) = "r"
    show (Circle Blue) = "b"
    show (Circle Gray) = "g"
    show (Arrow heading) = show heading

{-
    *** TODO ***

    Un nivel al jocului.

    Recomandăm Data.Map.Strict.
-}
data Level = L (M.Map Position (Maybe Object, Maybe Object))
    deriving (Eq, Ord)

{-
    *** TODO ***

    Reprezetarea textuală a unui nivel.
-}
showTuple :: (Maybe Object, Maybe Object) -> String
showTuple (Just s@(Square _ _), Nothing) = show s ++ " "
showTuple (Just s@(Square _ _), Just c) = show s ++ show c
showTuple (Nothing, Just c) = "  " ++ show c
showTuple (Nothing, Nothing) = "   "

cartProduct :: [a] -> [b] -> [(a, b)]
cartProduct a b = [(x, y)| x <- a, y <- b]

instance Show Level where
    show (L l) = foldl f [] lista
        where 
            minLine = M.foldlWithKey fMinLine 9999 l
            fMinLine acc k element
               | acc < fst k = acc
               | otherwise = fst k
            maxLine = M.foldlWithKey fMaxLine (-9999) l
            fMaxLine acc k element
               | acc > fst k = acc
               | otherwise = fst k
            minCol = M.foldlWithKey fMinCol 9999 l
            fMinCol acc k element
               | acc < snd k = acc
               | otherwise = snd k
            maxCol = M.foldlWithKey fMaxCol (-9999) l
            fMaxCol acc k element
               | acc > snd k = acc
               | otherwise = snd k
            f acc key
                | (M.member key l) = acc ++ showTuple (l M.! key) ++ if snd key == maxCol then
                    if fst key == maxLine then "" else "\n" else "|"
                | otherwise = acc ++ "   " ++ if snd key == maxCol then
                    if fst key == maxLine then "" else "\n" else "|"
            lista = cartProduct [minLine .. maxLine] [minCol .. maxCol]
    
{-
    *** TODO ***

    Nivelul vid, fără obiecte.
-}
emptyLevel :: Level
emptyLevel = L M.empty

{-
    *** TODO ***

    Adaugă un pătrat cu caracteristicile date la poziția precizată din nivel.
-}
addSquare :: Color -> Heading -> Position -> Level -> Level
addSquare c h p (L l) = L $ M.insertWith fct p (Just (Square c h), Nothing) l where
	fct new old = (Just (Square c h), snd old)

{-
    *** TODO ***

    Adaugă un cerc cu caracteristicile date la poziția precizată din nivel.
-}
addCircle :: Color -> Position -> Level -> Level
addCircle c p (L l) = L $ M.insertWith fct p (Nothing, Just (Circle c)) l where
	fct new old = (fst old, Just (Circle c))

{-
    *** TODO ***

    Adaugă o săgeată cu caracteristicile date la poziția precizată din nivel.
-}
addArrow :: Heading -> Position -> Level -> Level
addArrow h p (L l) = L $ M.insertWith fct p (Nothing, Just (Arrow h)) l where
	fct new old = (fst old, Just (Arrow h))

{-
    *** TODO ***

    Mută pătratul de la poziția precizată din nivel. Dacă la poziția respectivă
    nu se găsește un pătrat, întoarce direct parametrul.
-}
moveTo :: Maybe Object -> Position -> Position
moveTo (Just (Square _ North)) (x, y) = (x - 1, y)
moveTo (Just (Square _ South)) (x, y) = (x + 1, y)
moveTo (Just (Square _ West)) (x, y) = (x, y - 1)
moveTo (Just (Square _ East)) (x, y) = (x, y + 1)

move :: Position  -- Poziția
     -> Level     -- Nivelul inițial
     -> Level     -- Nivelul final
move p l@(L level) = L $ moveS p (fst (level M.! p)) level


moveS :: Position
      -> Maybe Object
      -> M.Map Position (Maybe Object, Maybe Object)
      -> M.Map Position (Maybe Object, Maybe Object)
moveS p square level
    | M.member p level == False = level
    | fst (level M.! p) == Nothing = level
    | M.member new_pos level == False = new_level1
    | snd (level M.! new_pos) == Just (Arrow North) = new_level2 North
    | snd (level M.! new_pos) == Just (Arrow South) = new_level2 South
    | snd (level M.! new_pos) == Just (Arrow East) = new_level2 East
    | snd (level M.! new_pos) == Just (Arrow West) = new_level2 West
    | otherwise = new_level1
        where
            (L new_level1) = addSquare color heading new_pos tmp_level  
            new_level2 heading2 = rez where (L rez) = addSquare color heading2 new_pos tmp_level
            Just (Square color heading) = fst (level M.! p)
            tmp_level = L $ M.update updateFunc p $ moveS new_pos square level
            new_pos = moveTo square p
            updateFunc _
                | snd (level M.! p) == Nothing = Nothing
                | otherwise = Just (Nothing, snd (level M.! p))

{-
    *** TODO ***

    Instanțiați clasa `ProblemState` pentru jocul nostru.
-}
instance ProblemState Level Position where
    successors l@(L start_level) = M.foldlWithKey (\res k v -> if fst v == Nothing then res else res ++ [(k, (move k l))]) [] start_level

    isGoal (L l) = if cercuri == patrateCercuri then True else False where
        cercuri = M.foldl f 0 l where
            f acc (_, Just (Circle _)) = acc + 1
            f acc (_,_) = acc
        patrateCercuri = M.foldl f 0 l where
            f acc (Just (Square color1 _), Just (Circle color2)) = if (color1 == color2) then acc + 1 else acc
            f acc (_, _) = acc

    -- Doar petru BONUS
    -- heuristic =
