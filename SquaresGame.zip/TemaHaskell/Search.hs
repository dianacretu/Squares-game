{-# OPTIONS_GHC -Wall #-}

module Search where

import ProblemState

import qualified Data.Set as S

{-
    *** TODO ***

    Tipul unei nod utilizat în procesul de căutare. Recomandăm reținerea unor
    informații legate de:

    * stare;
    * acțiunea care a condus la această stare;
    * nodul părinte, prin explorarea căruia a fost obținut nodul curent;
    * adâncime.
-}
data Node s a = N s (Maybe a) (Maybe (Node s a))
    deriving (Eq, Show)

{-
    *** TODO ***

    Întoarce starea stocată într-un nod.
-}
nodeState :: Node s a -> s
nodeState (N s _ _) = s

{-
    *** TODO ***

    Întoarce lista nodurilor rezultate prin parcurgerea limitată în adâncime
    a spațiului stărilor, pornind de la starea dată ca parametru.

    Pentru reținerea stărilor vizitate, recomandăm Data.Set. Constrângerea
    `Ord s` permite utilizarea tipului `Set`.

    În afara BONUS-ului, puteți ignora parametrul boolean. Pentru BONUS, puteți
    sorta lista succesorilor folosind `sortBy` din Data.List.
-}
limitedDfs :: (ProblemState s a, Ord s)
           => s           -- Starea inițială
           -> Bool        -- Pentru BONUS, `True` dacă utilizăm euristica
           -> Int         -- Adâncimea maximă de explorare
           -> [Node s a]  -- Lista de noduri
limitedDfs initialState b maxDepth = dfs [(N initialState Nothing Nothing, 0)] []
    where
        dfs [] visited = reverse visited
        dfs ((x@(N state _ _), depth):xs) visited
            | any (equalNodes x) visited = dfs xs visited
            | depth == maxDepth = dfs xs (x : visited)
            | otherwise = 
                let asuccesori = succesori x (depth + 1)
                in  dfs ((++) asuccesori xs) (x:visited)

equalNodes :: (Eq s) => Node s a -> Node s a -> Bool
equalNodes (N state1 _ _) (N state2 _ _) = state1 == state2

succesori :: (ProblemState s a, Ord s) => Node s a -> Int -> [(Node s a, Int)]
succesori parent@(N state _ _) depth = map (\(a, s) -> ((N s (Just a) (Just parent)), depth)) (successors state)

{-
    *** TODO ***

    Explorează în adâncime spațiul stărilor, utilizând adâncire iterativă,
    pentru determinarea primei stări finale întâlnite.

    Întoarce o perche între nodul cu prima stare finală întâlnită și numărul
    de stări nefinale vizitate până în acel moment.

    În afara BONUS-ului, puteți ignora parametrul boolean.
-}
iterativeDeepening :: (ProblemState s a, Ord s, Eq a)
    => s                -- Starea inițială
    -> Bool             -- Pentru BONUS, `True` dacă utilizăm euristica
    -> (Node s a, Int)  -- (Nod cu prima stare finală,
                        --  număr de stări nefinale vizitate)
iterativeDeepening state b = findG 0 [] where
    findG maxDepth l
        | nodM2 == Nothing = findG (maxDepth + 1) (l ++ limitedDfs state b (maxDepth))
        | otherwise = (nod, noduri)
            where
                (nodM@(Just nod), noduri) = checkGoal l
                (nodM2, noduri2) = checkGoal l

checkGoal :: (ProblemState s a, Eq a, Eq s) => [Node s a] -> (Maybe (Node s a), Int)
checkGoal l = foldl func (Nothing, 0) l
    where
        func acc@(x, y) nod@(N state _ _)
            | isGoal state = ((Just nod), y)
            | x == Nothing = (x, (y + 1))
            | otherwise = acc

{-
    *** TODO ***

    Pornind de la un nod, reface calea către nodul inițial, urmând legăturile
    către părinți.

    Întoarce o listă de perechi (acțiune, stare), care se încheie în starea
    finală, dar care EXCLUDE starea inițială.
-}
extractPath :: Node s a -> [(a, s)]
extractPath (N s Nothing _) = [] 
extractPath (N s (Just a) (Just parent)) = (extractPath parent) ++ [(a,s )]

{-
    Poate fi utilizată pentru afișarea fiecărui element al unei liste
    pe o linie separată.
-}
printSpacedList :: Show a => [a] -> IO ()
printSpacedList = mapM_ (\a -> print a >> putStrLn (replicate 20 '*'))